var WIDTH = 800;
var HEIGHT = 600;
var WINNING_SEQUENCES = [
  // Symbol AA winning
  [[0, 0, 0, 0, 0], 125], //if this comes in a row of reels then winning is 125
  [[0, 0, 0, 0], 25], //if this comes in a row of reels then winning is 25
  [[0, 0, 0], 5], //if this comes in a row of reels then winning is 5
  [[0, 0], 2], //if this comes in a row of reels then winning is 2
  // Symbol BB winning
  [[1, 1, 1, 1, 1], 125],
  [[1, 1, 1, 1], 50],
  [[1, 1, 1], 5],
  [[1, 1], 2],
  // Symbol CC winning
  [[2, 2, 2, 2, 2], 200],
  [[2, 2, 2, 2], 50],
  [[2, 2, 2], 10],
  [[2, 2], 5],
  // Symbol DD winning
  [[3, 3, 3, 3, 3], 250],
  [[3, 3, 3, 3], 50],
  [[3, 3, 3], 10],
  [[3, 3], 5],
  // Symbol EE winning
  [[4, 4, 4, 4, 4], 350],
  [[4, 4, 4, 4], 75],
  [[4, 4, 4], 10],
  [[4, 4], 5],
  // Symbol FF winning
  [[5, 5, 5, 5, 5], 400],
  [[5, 5, 5, 5], 80],
  [[5, 5, 5], 20],
  [[5, 5], 10],
  // Symbol GG winning
  [[6, 6, 6, 6, 6], 500],
  [[6, 6, 6, 6], 100],
  [[6, 6, 6], 25],
  [[6, 6], 10],
  // Symbol WC winning
  [[7, 7, 7, 7, 7], 2500],
  [[7, 7, 7, 7], 250],
  [[7, 7, 7], 50],
  [[7, 7], 25],
];

var PAYLINES = [
  [
    [0, 1],
    [1, 1],
    [2, 1],
    [3, 1],
    [4, 1],
  ],
  [
    [0, 0],
    [1, 0],
    [2, 0],
    [3, 0],
    [4, 0],
  ],
  [
    [0, 2],
    [1, 2],
    [2, 2],
    [3, 2],
    [4, 2],
  ],
  [
    [0, 0],
    [1, 1],
    [2, 2],
    [3, 1],
    [4, 0],
  ],
  [
    [0, 2],
    [1, 1],
    [2, 0],
    [3, 1],
    [4, 2],
  ],
];

var canvas = $(
  '<canvas width ="' + WIDTH + '" height="' + HEIGHT + '"></canvas>'
);
var ctx = canvas.get(0).getContext("2d");
$(canvas).appendTo("#stage");

var background_img_ready = false;
var background_img = new Image();
background_img.onload = function () {
  background_img_ready = true;
};
background_img.src = "img/background.png";

var symbol1_active = false;
var symbol1 = new Image();
symbol1.onload = function () {
  symbol1_active = true;
};
symbol1.src = "img/AA.jpg";

var symbol2_active = false;
var symbol2 = new Image();
symbol2.onload = function () {
  symbol2_active = true;
};
symbol2.src = "img/BB.jpg";

var symbol3_active = false;
var symbol3 = new Image();
symbol3.onload = function () {
  symbol3_active = true;
};
symbol3.src = "img/CC.jpg";

var symbol4_active = false;
var symbol4 = new Image();
symbol4.onload = function () {
  symbol4_active = true;
};
symbol4.src = "img/DD.jpg";

var symbol5_active = false;
var symbol5 = new Image();
symbol5.onload = function () {
  symbol5_active = true;
};
symbol5.src = "img/EE.jpg";

var symbol6_active = false;
var symbol6 = new Image();
symbol6.onload = function () {
  symbol6_active = true;
};
symbol6.src = "img/FF.jpg";

var symbol7_active = false;
var symbol7 = new Image();
symbol7.onload = function () {
  symbol7_active = true;
};
symbol7.src = "img/GG.jpg";

var symbol_wild_active = false;
var symbol_wild = new Image();
symbol_wild.onload = function () {
  symbol_wild_active = true;
};
symbol_wild.src = "img/WC.jpg";

var payline_point1_active = false;
var payline_point1 = new Image();
payline_point1.onload = function () {
  payline_point1_active = true;
};
payline_point1.src = "img/payline_points1.png";

var payline_point2_active = false;
var payline_point2 = new Image();
payline_point2.onload = function () {
  payline_point2_active = true;
};
payline_point2.src = "img/payline_points2.png";

var payline_point3_active = false;
var payline_point3 = new Image();
payline_point3.onload = function () {
  payline_point3_active = true;
};
payline_point3.src = "img/payline_points3.png";

var payline_point4_active = false;
var payline_point4 = new Image();
payline_point4.onload = function () {
  payline_point4_active = true;
};
payline_point4.src = "img/payline_points4.png";

var payline_point5_active = false;
var payline_point5 = new Image();
payline_point5.onload = function () {
  payline_point5_active = true;
};
payline_point5.src = "img/payline_points5.png";

var line1_img_active = false;
var line1_img = new Image();
line1_img.onload = function () {
  line1_img_active = true;
};
line1_img.src = "img/line1.png";

var line2_img_active = false;
var line2_img = new Image();
line2_img.onload = function () {
  line2_img_active = true;
};
line2_img.src = "img/line2.png";

var line3_img_active = false;
var line3_img = new Image();
line3_img.onload = function () {
  line3_img_active = true;
};
line3_img.src = "img/line3.png";

var line4_img_active = false;
var line4_img = new Image();
line4_img.onload = function () {
  line4_img_active = true;
};
line4_img.src = "img/line4.png";

var line5_img_active = false;
var line5_img = new Image();
line5_img.onload = function () {
  line5_img_active = true;
};
line5_img.src = "img/line5.png";

function payline_check(result, payline_format) {
  for (var i = 0; i < payline_format.length; i++) {
    if (payline_format[i] != result[i]) {
      return false;
    }
  }
  return true;
}

function paylineResult_reel(payline_map) {
  var results = [];
  for (var i = 0; i < payline_map.length; i++) {
    var reel_number = payline_map[i][0];
    var row = payline_map[i][1];
    results.push(reels_top[reel_number].tiles[row]);
  }
  return results;
}

function get_payline_result(payline_checking) {
  var paylines_result = [];
  for (var i = 0; i < payline_checking; i++) {
    paylines_result.push(paylineResult_reel(PAYLINES[i]));
  }
  return paylines_result;
}

function winning(result) {
  game_state.shown_symbols = [];
  for (var i = 0; i < result.length; i++) {
    for (var j = 0; j < WINNING_SEQUENCES.length; j++) {
      if (payline_check(result[i], WINNING_SEQUENCES[j][0])) {
        game_state.win += WINNING_SEQUENCES[j][1];
        game_state.shown_symbols.push(i);
        game_state.current_line_winnings_map.push([i, WINNING_SEQUENCES[j][1]]);
        break;
      }
    }
  }
}

function rotate_symbols() {
  game_state.show_symbols = true;
  game_state.current_showed_symbols_count++;
  var current_index =
    game_state.current_showed_symbols_count % game_state.shown_symbols.length;
  game_state.current_shown_symbols = game_state.shown_symbols[current_index];
}

function GameState(
  win,
  paid,
  credits,
  bet,
  tiles,
  shown_symbols,
  show_symbols
) {
  this.win = win;
  this.paid = paid;
  this.credits = credits;
  this.bet = bet;
  this.tiles = tiles;
  this.shown_symbols = shown_symbols;
  this.show_symbols = show_symbols;
  this.current_shown_symbols = 0;
  this.current_showed_symbols_count = 0;
  this.rotate_highlight_loop = null;
  this.spin_click_shield = false;
  this.show_lines = true;
  this.current_line_winnings_map = [];
  this.transfer_win_to_credits = function () {
    var i = this.win;
    var counter = 0;
    while (i > 0) {
      i -= 1;
      counter += 50;
      setTimeout(function () {
        // coin_sound.currentTime = 0;
        // coin_sound.play();
        game_state.paid += 1;
        game_state.credits += 1;
        if (game_state.win == game_state.paid) {
          game_state.spin_click_shield = false;
        }
      }, counter);
    }
  };
}

var game_state = new GameState(0, 0, 50, 1, [], [], true);

game_state.tiles.push(new Tile("whitebook", symbol1, "1"));
game_state.tiles.push(new Tile("greenbook", symbol2, "1"));
game_state.tiles.push(new Tile("ia", symbol3, "1"));
game_state.tiles.push(new Tile("money", symbol4, "1"));
game_state.tiles.push(new Tile("seattle", symbol5, "1"));
game_state.tiles.push(new Tile("car", symbol6, "1"));
game_state.tiles.push(new Tile("fruit", symbol7, "1"));
game_state.tiles.push(new Tile("lucky", symbol_wild, "1"));

function Tile(name, img, value) {
  this.name = name;
  this.img = img;
  this.value = value;
}

function Reel(x, y, x_vel, y_vel, y_acc, tiles) {
  this.x = x;
  this.y = y;
  this.x_vel = x_vel;
  this.y_vel = y_vel;
  this.y_acc = y_acc;
  this.tiles = tiles;
  this.draw = function () {
    for (var i = 0; i < this.tiles.length; i++) {
      y_offset = this.y + 100 * i + 19;
      ctx.drawImage(
        game_state.tiles[this.tiles[i]].img,
        0,
        0,
        100,
        100,
        this.x,
        y_offset,
        100,
        100
      );
    }
  };
  this.update = function (modifier) {
    this.y += this.y_vel;
  };
}

function ButtonObject(x, y, width, height, handler) {
  this.x = x;
  this.y = y;
  this.width = width;
  this.height = height;

  this.handleClick = function (mouse) {
    if (
      this.x < mouse.x &&
      this.x + this.width > mouse.x &&
      this.y < mouse.y &&
      this.y + this.height > mouse.y
    ) {
      handler();
      return true;
    }

    return false;
  };

  this.draw = function () {
    ctx.fillStyle = "white";
    ctx.fillRect(this.x, this.y, this.width, this.height);
  };
}

function BetButton(x, y, width, height, handler, bet_amount) {
  ButtonObject.apply(this, arguments);
  this.bet_amount = bet_amount;
  this.handleClick = function (mouse) {
    if (
      this.x < mouse.x &&
      this.x + this.width > mouse.x &&
      this.y < mouse.y &&
      this.y + this.height > mouse.y
    ) {
      handler(bet_amount);
      game_state.show_lines = true;
      game_state.show_symbols = false;
      // bet_sound.currentTime = 0;
      // bet_sound.play();
      return true;
    }
  };
}

var change_bet_amount = function (bet_amount) {
  game_state.bet = bet_amount;
};

var reels_top = [];

var spin_handler = function () {
  if (game_state.spin_click_shield) {
    return;
  }
  // spin_sound.currentTime = 0;
  // spin_sound.play();
  setTimeout(function () {
    // spin_sound.pause();
  }, 1600);
  game_state.spin_click_shield = true;
  clearInterval(game_state.rotate_highlight_loop);
  game_state.current_showed_symbols_count = 0;
  game_state.rotate_highlight_loop = 0;
  game_state.paid = 0;
  game_state.win = 0;
  game_state.credits -= game_state.bet;
  game_state.show_symbols = false;
  game_state.show_lines = false;
  game_state.current_line_winnings_map = [];
  for (var i = 0; i < reels_bottom.length; i++) {
    reels_top = generate_reels(-1000);
    animate_reels(i);
  }
  setTimeout(function () {
    winning(get_payline_result(game_state.bet));
    game_state.transfer_win_to_credits();
    game_state.rotate_highlight_loop = setInterval(rotate_symbols, 2000);
    if (game_state.win == game_state.paid) {
      game_state.spin_click_shield = false;
    }
  }, 1500);
};

var animate_reels = function (index) {
  setTimeout(function () {
    reels_top[index].y_vel = 15;
    reels_bottom[index].y_vel = 15;
  }, 100 * index);
};

var button_object_array = [
  new ButtonObject(550, 450, 86, 80, spin_handler),
  // ,
  // new BetButton(319, 450, 64, 57, change_bet_amount, 5),
  // new BetButton(242, 450, 64, 57, change_bet_amount, 3),
  // new BetButton(165, 450, 64, 57, change_bet_amount, 1),
];

function generate_random_tile_list(num) {
  var random_tile_list = [];
  for (var i = 0; i < num; i++) {
    var random_num = Math.floor(Math.random() * game_state.tiles.length);
    random_tile_list.push(random_num);
  }
  return random_tile_list;
}

var generate_reels = function (starting_y) {
  var reels = [];
  reels.push(new Reel(150, starting_y, 0, 0, 0, generate_random_tile_list(10)));
  reels.push(new Reel(250, starting_y, 0, 0, 0, generate_random_tile_list(10)));
  reels.push(new Reel(350, starting_y, 0, 0, 0, generate_random_tile_list(10)));
  reels.push(new Reel(450, starting_y, 0, 0, 0, generate_random_tile_list(10)));
  reels.push(new Reel(550, starting_y, 0, 0, 0, generate_random_tile_list(10)));
  return reels;
};

var reels_bottom = generate_reels(0);

function draw_reel(reel) {
  for (var i = 0; i < reel.tiles.length; i++) {
    y_offset = 100 * i;
    ctx.drawImage(
      game_state.tiles[reel.tiles[i]].img,
      0,
      0,
      100,
      100,
      reel.x,
      y_offset,
      100,
      100
    );
  }
}

var keysDown = {};

addEventListener(
  "keydown",
  function (e) {
    keysDown[e.keyCode] = true;
    switch (e.keyCode) {
      case 37:
      case 39:
      case 38:
      case 40:
      case 32:
        e.preventDefault();
        break;
      default:
        break;
    }
    if (e.keyCode == 32) {
    }
  },
  false
);

addEventListener(
  "keyup",
  function (e) {
    delete keysDown[e.keyCode];
  },
  false
);

var canvasPosition = {
  x: canvas.offset().left,
  y: canvas.offset().top,
};

canvas.on("click", function (e) {
  var mouse = {
    x: e.pageX - canvasPosition.x + 200,
    y: e.pageY - canvasPosition.y + 80,
  };

  for (var i = 0; i < button_object_array.length; i++) {
    button_object_array[i].handleClick(mouse);
  }
});

var reset = function () {};
var update = function (modifier) {
  for (var i = 0; i < reels_bottom.length; i++) {
    reels_bottom[i].update(modifier);
  }
  for (var i = 0; i < reels_top.length; i++) {
    if (reels_top[i].y >= 0) {
      reels_top[i].y_vel = 0;
      reels_bottom = reels_top;
      reels_bottom[i].y = 0;
    }
    reels_top[i].update(modifier);
  }
};

var render = function () {
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  for (var i = 0; i < reels_bottom.length; i++) {
    reels_bottom[i].draw();
  }
  for (var i = 0; i < reels_top.length; i++) {
    reels_top[i].draw();
  }

  for (var i = 0; i < button_object_array.length; i++) {
    button_object_array[i].draw();
  }

  ctx.drawImage(background_img, 0, 0, 800, 600, 0, 0, 800, 600);

  ctx.fillStyle = "#7F9500";
  ctx.font = "14px 'Press Start 2P'";
  ctx.textAlign = "right";
  ctx.textBaseline = "top";
  ctx.fillText(game_state.win, 200, 380);
  ctx.fillText(game_state.paid, 200, 440);
  ctx.fillText(game_state.credits, 605, 380);
  ctx.fillText(game_state.bet, 605, 440);

  if (
    game_state.show_symbols &&
    game_state.shown_symbols.length &&
    !game_state.show_lines
  ) {
    var winnings_x_coord = 155;
    var winnings_y_coord = 0;
    switch (game_state.current_shown_symbols) {
      case 0:
        ctx.fillStyle = "rgba(0, 147, 68, 0.5)";
        winnings_y_coord = 125;
        break;
      case 1:
        ctx.fillStyle = "rgba(214, 223, 35, 0.5)";
        winnings_y_coord = 25;
        break;
      case 2:
        ctx.fillStyle = "rgba(42, 56, 143, 0.5)";
        winnings_y_coord = 225;
        break;
      case 3:
        ctx.fillStyle = "rgba(237, 28, 36, 0.5)";
        winnings_y_coord = 25;
        break;
      case 4:
        ctx.fillStyle = "rgba(211, 91, 146, 0.5)";
        winnings_y_coord = 225;
        break;
      case 5:
        ctx.fillStyle = "rgba(251, 175, 63, 0.5)";
        winnings_y_coord = 25;
        break;
      case 6:
        ctx.fillStyle = "rgba(101, 44, 144, 0.5)";
        winnings_y_coord = 225;
        break;
      case 7:
        ctx.fillStyle = "rgba(140, 198, 62, 0.5)";
        winnings_y_coord = 125;
        break;
      case 8:
        ctx.fillStyle = "rgba(0, 173, 239, 0.5)";
        winnings_y_coord = 125;
        break;
    }
    for (var j = 0; j < 5; j++) {
      var x_coord =
        PAYLINES[game_state.current_shown_symbols][j][0] * 100 + 150;
      var y_coord = PAYLINES[game_state.current_shown_symbols][j][1] * 100 + 20;
      ctx.fillRect(x_coord, y_coord, 100, 100);
    }
    for (var i = 0; i < game_state.current_line_winnings_map.length; i++) {
      if (
        game_state.current_line_winnings_map[i][0] ==
        game_state.current_shown_symbols
      ) {
        ctx.textAlign = "left";
        ctx.fillStyle = "#231F20";
        ctx.fillText(
          game_state.current_line_winnings_map[i][1],
          winnings_x_coord,
          winnings_y_coord
        );
      }
    }
  }

  if (game_state.bet >= 1) {
    ctx.drawImage(payline_point1, 0, 0, 561, 301, 117, 20, 561, 301);
    if (game_state.show_lines) {
      ctx.drawImage(line1_img, 0, 0, 561, 301, 117, 20, 561, 301);
    }
  }
  if (game_state.bet >= 3) {
    ctx.drawImage(payline_point2, 0, 0, 561, 301, 117, 20, 561, 301);
    ctx.drawImage(payline_point3, 0, 0, 561, 301, 117, 20, 561, 301);
    if (game_state.show_lines) {
      ctx.drawImage(line2_img, 0, 0, 561, 301, 117, 20, 561, 301);
      ctx.drawImage(line3_img, 0, 0, 561, 301, 117, 20, 561, 301);
    }
  }
  if (game_state.bet >= 5) {
    ctx.drawImage(payline_point4, 0, 0, 561, 301, 117, 20, 561, 301);
    ctx.drawImage(payline_point5, 0, 0, 561, 301, 117, 20, 561, 301);
    if (game_state.show_lines) {
      ctx.drawImage(line4_img, 0, 0, 561, 301, 117, 20, 561, 301);
      ctx.drawImage(line5_img, 0, 0, 561, 301, 117, 20, 561, 301);
    }
  }
};

var main = function () {
  var now = Date.now();
  var delta = now - then;

  update(delta / 1000);
  render();

  then = now;
};

reset();
var then = Date.now();
var main_loop = setInterval(main, 16);
